package co.edu.uptc.Sistemas_Electricos_y_Energeticos.Model;

public class Nodo {

}
